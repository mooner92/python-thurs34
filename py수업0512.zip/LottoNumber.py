import random

## 전역변수
lotto = [ ]

## 메인코드 부분
print("로또 번호 6개를 추천합니다")

while True :
    num = random.randrange(1,46)

    if lotto.count(num) == 0 :
        lotto.append(num)
        
    if len(lotto) >= 6 :
        break
    
lotto.sort()
print(lotto)
