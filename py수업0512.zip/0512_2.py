import random

a = random.randrange(1,46)
