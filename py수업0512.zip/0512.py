"""
import LottoNumber_Function
import random
lotto=[]

LottoNumber_Function.printTitle()
LottoNumber_Function.getLottoNumber()
LottoNumber_Function.printLotto()

lotto=[]
printTitle()
grtLottoNumber()
printLotto()
"""


"""
inFp = None     # 입력파일용 변수명
inStr = ""      # 읽은 문자 저장할 변수

inFp = open("d:\memo.txt",encoding="utf-8")		# cp949 에러가 나오면 아래 encoding 내용 추가
#inFp = open("C:/Temp/py_data1.txt", encoding="utf-8")

inStr = inFp.readline()		# 한줄만 읽어옴 0 번째줄
print(inStr,end="")
inStr = inFp.readline()		# 한줄만 읽어옴 1 번째줄
print(inStr,end="")
inStr = inFp.readline()		# 한줄만 읽어옴 2 번째줄
print(inStr,end="")
inStr = inFp.readline()		# 한줄만 읽어옴 3 번째줄
print(inStr,end="")


while True:
    if(inStr==""):
        break;
    inStr = inFp.readline()
    print(inStr,end="")
inFp.close()

"""


outFp = None
outStr = ""
outFp = open("d:/py_data2.txt", "w")
while True :
	outStr = input("파일에 쓸 내용 입력 : ")
	if outStr != "" :					# enter 치지 않으면
		outFp.writelines(outStr + "\n")		# 줄바꿈문자를 추가
	else :
		break
outFp.close()
