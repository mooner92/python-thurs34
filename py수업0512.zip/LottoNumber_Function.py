import random

## 함수 선언 부분

def printTitle() :
    print("로또 번호 6개를 추천합니다")

def getLottoNumber() :

    ## 내부 함수 선언 부분
    
    def getNumber() :
        return random.randrange(1,46)
        

    def isNotNumInLotto( n ) :
        return lotto.count(num) == 0

    def isContinue() :
        return len(lotto) < 6

    def putNumInLotto ( n ) :
        return lotto.append(num)
    
    while True :
        num = getNumber()

        if isNotNumInLotto(num) :
            putNumInLotto(num)

        if isContinue() :
            pass
        else :
            break
        
def printLotto() :
    print(lotto)

## 전역변수
lotto = []

## 메인코드 부분
printTitle()
getLottoNumber()
printLotto()
