import csv

f = open("age.csv")
data = csv.reader(f)
result1 = []
result2 = []
for row in data:  #for 안쪽부분 빈칸 시험문제
    #print(row)
    if "금암동"in row[0]:
        for i in row[3:] :
            result1.append(int(i))
    if "관저1동" in row[0]:
        for i in row[3:]:
            result2.append(int(i))


import matplotlib.pyplot as plt
plt.style.use('grayscale')
plt.plot(result1,label="gyeryong",color='dimgray',marker='o',linestyle='--')
plt.plot(result2,label="gwanjeo1dong",color='black',marker='o',linestyle='--')
plt.xlabel('[ Age ]')
plt.ylabel('[ peoples ]')
plt.legend()
plt.grid(True)
plt.show()
    
