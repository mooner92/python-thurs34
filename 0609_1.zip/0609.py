import matplotlib.pyplot

matplotlib.pyplot.plot([1,2,3,1],[20,10,20,20])
matplotlib.pyplot.show()
