a = int(input("a의값을 입력하세요."))
b = int(input("b의값을 입력하세요."))

result  = a+b
print("a+b=",result)
result  = a-b
print("a-b=",result)
result  = a*b
print("a*b=",result)
result  = a/b
print("a/b=",result)

