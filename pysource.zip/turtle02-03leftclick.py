import turtle
import random
#은 주석입니다.
##함수 선언부##
def slc(x,y):
    global r,g,b
    turtle.pencolor((r,g,b))  #(r,g,b)를 넘김
    turtle.pendown()     #펜촉이 종이에 닿게끔 내리는 작업
    turtle.goto(x,y)    #x,y좌표로 이동

def src(x,y):
    turtle.penup()     #펜촉이 종이에 닿게끔 내리는 작업
    turtle.goto(x,y)   #x,y좌표로 이동

def smc(x,y):
    global r,g,b
    tsize = random.randrange(1, 10)  #1에서 10까지의 난수를 뽑아내어 tsize에 저장
    turtle.shapesize(tsize)    #앞에서 발생한 난수로 거북이의 크기를 정해줌
    r = random.random()
    g = random.random()
    b = random.random()


## 변수 선언부 ##
r, g, b = 0.0, 0.0, 0.0
psize = 10
##메인 코드 부분##
turtle.shape('turtle')
turtle.pensize(psize)
turtle.color("blue")
turtle.title("거북이로그림그리기")  #윈도우 창 타이틍 넣기
turtle.onscreenclick(slc, 1) # 1:왼쪽클릭 2:중간(휠)클릭 3:오른쪽클릭
turtle.onscreenclick(src, 3)
turtle.onscreenclick(smc, 2)
turtle.done()
