a=100
b=200
print(a+b)
print(a-b)
print(a*b)
print(a/b)

print("a+b=" , a+b)
print("a-b=" + a-b)
print("a*b=" + a-b)
print("a/b=" + a/b)
