import turtle
n= 200
r=90
turtle.shape('turtle')
turtle.speed(0)
turtle.forward(n)
turtle.right(r)
turtle.forward(n) 
turtle.right(r)
turtle.forward(n)
turtle.right(r)
turtle.forward(n)
turtle.right(r)

turtle.done()
