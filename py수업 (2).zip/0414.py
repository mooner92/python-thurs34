"""
sum=0
for i in range(150,201,2):
    sum+=i
print(sum)
"""

"""
cc = [5,3,2,1,0]
del(cc[2:4])
#출력값 = [5,3,0]
"""

"""
sum=0
bb = [1,2,3,4]
for i in range (2,len(bb)):
    sum+=bb[i]
print(sum)
"""

"""
aa=bb이면 얕은복사 -----레퍼런스임(메모리공유)
깊은복사를 하려면 bb=aa.copy()
==value형
"""

"""
dd = sorted(aa) 이면
메모리 할당해줌 ==다른객체
"""

"""
ss3 = "AbhfJgfnFHNHFbgtvnH"
ss3.swapcase()
'aBHFjGFNfhnhfBGTVNh'
"""
