gugu = [ [0 for i in range(9)] for j in range(8)]
for i in range(2,10):
    for j in range(1,10):
            gugu[i-2][j-1] = i*j
print(gugu)
