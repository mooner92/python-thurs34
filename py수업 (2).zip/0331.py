import turtle          

​

def start():            

 

   t = turtle.Turtle()    

   t.pensize(2)            

   t.speed(0)            

​

   tunnelLength = int(turtle.textinput("터널의 길이","터널의 길이를 입력하시오 :(cm)"))

   

   

   t.goto(tunnelLength,0)

   t.goto(0,0)

   

   t.lt(60)

   t.fd(30)

   t.rt(60)

   

   t.fd(tunnelLength - 30)

   t.rt(60)

   t.fd(30)

   

   t.hideturtle()

   

​

​

 

   name1Speed = int(turtle.textinput("사람1의 속도","사람1의 속도를 입력하시오 :(cm/sec)"))

   name2Speed = int(turtle.textinput("사람2의 속도","사람2의 속도를 입력하시오 :(cm/sec)"))

   rabbitSpeed = int(turtle.textinput("토끼의 속도","토끼의 속도를 입력하시오 :(cm/sec)"))

   

   if name1Speed == 0 and name2Speed == 0 and rabbitSpeed == 0:

       text.goto(0,-90)

       text.write("오류!!",font = ('맑은고딕',12,'bold'))

       return 0

 

   elif name1Speed == 0 and name2Speed == 0:

       text.goto(0,-90)

       text.write("오류!!",font = ('맑은고딕',12,'bold'))

       return 0

   answer = str(turtle.textinput("기진맥진","토끼가 터널길이보다 많이 뛰면 쓰러트리겠습니까?(yes,no)"))

 

​

   #사람1,2,토끼 생성

   

   name1 = turtle.Turtle()

   name1.color('red')

   name1.up()

   

​

   name2 = turtle.Turtle()

   name2.penup()

   name2.goto(tunnelLength,0)

   name2.left(180)

   

​

   rabbit = turtle.Turtle()

   rabbit.color('blue')

   rabbit.up()

   

   

   

   ##유턴 횟수, 거리, 시간  변수 생성 해준다.

   U_turncount = 0

   rabbit_distance = 0

   

   while True:

​

       

       name1_x = name1.xcor()

       name2_x = name2.xcor()

       rabbit_x = rabbit.xcor()

       

​

     

       

       if name1_x >= name2_x:          

           text.goto(0,-85)          

           text.write("유턴 횟수 :%d" % U_turncount,font = ('맑은고딕',12,'bold'))  

           text.goto(0,-105)                      

           text.write("토끼가 뛴거리 :%d" % rabbit_distance,font = ('맑은고딕',12,'bold'))

           text.goto(0,-125)

           time = rabbit_distance / rabbitSpeed  

           if time <0:

               time = -time

           text.write("걸린 시간 :%d 초" % time,font = ('맑은고딕',12,'bold'))

           break

       

       if rabbit_distance >= tunnelLength and answer == 'yes':

           text.goto(0,-105)      

           text.write("토끼가 힘들어서 쓰러졌습니다.",font = ('맑은고딕',12,'bold'))

           break

​

   

                   

       if rabbitSpeed > 0:    

           rabbit_distance += rabbitSpeed

       else:      

           rabbit_distance += -rabbitSpeed

​

       

       rabbit.setx(rabbit_x + rabbitSpeed)

       name1.setx(name1_x + name1Speed)

       name2.setx(name2_x - name2Speed)

       

           

       

       

       if  rabbit_x > name2_x - (2 * rabbitSpeed + 2 * name2Speed) :

           rabbit.left(180)

           rabbitSpeed = -rabbitSpeed

           U_turncount += 1

           

       elif rabbit_x < name1_x + (-2*rabbitSpeed + 2 * name1Speed) :

           rabbit.left(180)

           rabbitSpeed = -rabbitSpeed

           U_turncount += 1

​

       

       elif rabbit_x == name2_x or rabbit_x == name1_x and U_turncount > 0 :

           time = rabbit_distance / rabbitSpeed

           

           if time <0:

               time = -time

           text.goto(0,-105)

           text.write("토끼가 잡혔습니다.",font = ('맑은고딕',12,'bold'))

           text.goto(0,-125)

           text.write("걸린 시간 :%d " % time,font = ('맑은고딕',12,'bold'))

           break

​

​

text = turtle.Turtle()  

text.speed(0)  

text.hideturtle()  

text.up()  

start()
