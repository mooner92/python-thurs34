#fruit = ['apple','banana','melon','kiwi']
#print(fruit)
#if('apple' in fruit) :
   #print("apple is in array")
#for index in range(6,-1,-1):
    #print(index,end="\t")
for index in range(1,10):
    for k in range(2,10):
        #print(index,k,end=" ")
        if(index ==1):
            print("#      %d단      #"%k,end= " ")
        else :
            print("%d * %d = %d      "%(k,index,index*k),end=" ")
    print("")
