Python 3.9.5 (tags/v3.9.5:0a7dcbd, May  3 2021, 17:13:28) [MSC v.1928 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> aa = [0,1,2]
>>> bb = [3,4,5]
>>> aa
[0, 1, 2]
b
>>> b
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    b
NameError: name 'b' is not defined
>>> bb
[3, 4, 5]
>>> aa.extend(bb)
>>> aa
[0, 1, 2, 3, 4, 5]
>>> aa.extend(bb)
>>> aa
[0, 1, 2, 3, 4, 5, 3, 4, 5]
>>> cc = aa.copy()
>>> cc
[0, 1, 2, 3, 4, 5, 3, 4, 5]
>>> cc.remove(4)
>>> cc
[0, 1, 2, 3, 5, 3, 4, 5]
>>> aa
[0, 1, 2, 3, 4, 5, 3, 4, 5]
>>> bb
[3, 4, 5]
>>> bb = aa
>>> bb
[0, 1, 2, 3, 4, 5, 3, 4, 5]
>>> aa.remove(3)
>>> aa
[0, 1, 2, 4, 5, 3, 4, 5]
>>> bb
[0, 1, 2, 4, 5, 3, 4, 5]
>>> aa.remove(4,5)
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    aa.remove(4,5)
TypeError: list.remove() takes exactly one argument (2 given)
>>> aa.remove(5)
>>> aa
[0, 1, 2, 4, 3, 4, 5]
>>> bb
[0, 1, 2, 4, 3, 4, 5]
>>> aa.clear()
>>> aa
[]
>>> bb
[]
>>> aa = cc.copy()
>>> aa
[0, 1, 2, 3, 5, 3, 4, 5]
>>> dd = sorted(aa)
>>> dd
[0, 1, 2, 3, 3, 4, 5, 5]
>>> dd.remove(5)
>>> dd
[0, 1, 2, 3, 3, 4, 5]
>>> aa
[0, 1, 2, 3, 5, 3, 4, 5]
>>> aa.clear()
>>> bb.clear()
>>> cc.clear()
>>> dd.clear()
>>> ee.clear()
Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    ee.clear()
NameError: name 'ee' is not defined
>>> ss1 = "파이썬 수업"
>>> ss
Traceback (most recent call last):
  File "<pyshell#40>", line 1, in <module>
    ss
NameError: name 'ss' is not defined
>>> ss1
'파이썬 수업'
>>> ss1
'파이썬 수업'
>>> ss1
'파이썬 수업'
>>> ss1[2]
'썬'
>>> ss1[3]
' '
>>> ss1[4]
'수'
>>> ss1[-1:]
'업'
>>> ss1[:-1]
'파이썬 수'
>>> ss1[::]
'파이썬 수업'
>>> ss1[::-1]
'업수 썬이파'
>>> ss1[::2]
'파썬수'
>>> ss1[::-1]
'업수 썬이파'
>>> ss1 = "파이썬 abcd 456"
>>> ss1[4:6]
'ab'
>>> ss1[4:8]
'abcd'
>>> ss1.upper()
'파이썬 ABCD 456'
>>> ss1.lower()
'파이썬 abcd 456'
>>> ss1.swapcase()
'파이썬 ABCD 456'
>>> ss3 = "AbhfJgfnFHNHFbgtvnH"
>>> ss3.swapcase()
'aBHFjGFNfhnhfBGTVNh'
>>> ss3
'AbhfJgfnFHNHFbgtvnH'
>>> ss3.lower()
'abhfjgfnfhnhfbgtvnh'
>>> ss3
'AbhfJgfnFHNHFbgtvnH'
>>> ss4 = "fnaskjdnwaDSADS"
>>> ss4.title()
'Fnaskjdnwadsads'
>>> ss5 = ss4.title()
>>> ss5
'Fnaskjdnwadsads'
>>> ss5.lower()
'fnaskjdnwadsads'
>>> ss5.upper()
'FNASKJDNWADSADS'
>>> ss5
'Fnaskjdnwadsads'
>>> ss2.count('a')
Traceback (most recent call last):
  File "<pyshell#71>", line 1, in <module>
    ss2.count('a')
NameError: name 'ss2' is not defined
>>> ss3.count('a')
0
>>> ss3.count('a'+1)
Traceback (most recent call last):
  File "<pyshell#73>", line 1, in <module>
    ss3.count('a'+1)
TypeError: can only concatenate str (not "int") to str
>>> 