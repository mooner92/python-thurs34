if(0.0):
   print ("참")
if(-0.0):
   print ("참")
if(0.0):
   print ("참")

import turtle
import random

#변수 선언부#
swid,shei,psiz = 300,300,3
excnt = 0
r,g,b,angle,dis,curX,curY = [0]*7     #초기값 생 성

turtle.title("거북이가 돌아다니는 화면")
turtle.shape('turtle')
turtle.pensize(psiz)
turtle.setup(width=swid+30,height=shei+30)
turtle.screensize(swid,shei)
turtle.speed(100021312923829032100)

while True:
    s = random.random()
    r = random.random()
    g = random.random()
    b = random.random()
    turtle.pencolor((r,g,b))
    angle = random.randrange(0,360)
    dis = random.randrange(1,100)
    turtle.left(angle)
    turtle.forward(dis)
    turtle.shapesize(s)


    curX = turtle.xcor()
    curY = turtle.ycor()

    if(-swid/2<=curX and curX<= swid/2) and (-shei/2<=curY and curY<=shei/2):
        pass
    else:
        turtle.penup()
        turtle.goto(0,0)
        turtle.pendown()
        excnt+=1
        
        if(excnt>=3):
            break


    
    

turtle.done()
