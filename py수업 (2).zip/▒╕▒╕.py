
guguLine = ""

for i in range(2,10):
    guguLine +=("  #   %d단   #  "% i)

print(guguLine)

for index in range(1,10):
    for k in range(2,10):
        #print(index,k,end=" ")
        print("%2d * %2d = %2d"%(k,index,index*k))
    print("")
