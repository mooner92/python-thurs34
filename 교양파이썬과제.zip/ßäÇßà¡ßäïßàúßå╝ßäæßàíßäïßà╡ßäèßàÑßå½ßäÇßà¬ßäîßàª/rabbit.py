
T_L,A_S,B_S,R_S = map(int,input().split())
#터널길이,Q의속도,W의속도,토끼의 속도를 빈칸으로 나눠서 받아줌
if A_S==0 and B_S==0 and R_S==0:
    print("모두의 속도가 0이라면 토끼는 잡히지 않습니다.")  #예외처리 1
elif(A_S==0 and B_S==0):
    print("두 사람 모두 속도가 0이라면 토끼를 잡을 수 없습니다.")  #예외처리 2
#elif(A_S!=0 and B_S!=0 and R_S==0):
MS = 1000   ############시간단위를 바꾸고 싶다면 MS를 조절하면 됨
A=A_S/MS  #계산에 쓰일 더미값 선언 후 초를 1000으로 나누어 밀리초로 계산해줌(1밀리초에 A가 이동하는 거리)
B=B_S/MS  # ""
R=R_S/MS  # ""
TL=T_L    # T_L도 피봇을 생성
A_Dis,B_Dis,R_Dis,R_TDis,R_Uturn,Catch_Time = 0,0,1,0,0,0  # A가 간 거리 , B가 간 거리 , 토끼가 뛴 거리 , 유턴의 횟수 , 잡을 때 까지 걸리는 시간
################ 처음에 A랑 같은 곳에서 시작하게 하려면 R_Dis만 0로 바꿔주면 됨 ##################
while(1):  #초를 1000으로 나누어 밀리초로 계산해줌
    Catch_Time+=(1/MS)  #매 TC마다 0.001초씩 진행함
    A_Dis += A  # 매 TC마다 A_Dis에 A속력/MS 의 값을 계속 더해줌
    B_Dis += B  # 매 TC마다 B_Dis에 B속력/MS 의 값을 계속 더해줌
    R_Dis += R  # 매 TC마다 R_Dis에 R속력/MS 의 값을 계속 더해줌
    R_TDis += R # 매 TC마다 R_TDis에 R속력/MS 의 값을 계속 더해줌 ----지침거리 계산할 때 쓰이는 값임
    if(A_Dis>=R_Dis): #A나 B가 더 빨라서 추월당하는(닿기만해도 잡힘?) 경우
        break
    if(A_Dis>=(TL-B_Dis)): #A_Dis가 B_Pos를 초과하는(넘어가는) 순간 토끼는 잡힘
        break
    if(T_L<=R_TDis):  #토끼가 총 달린 길이가 초기T_L을 초과(넘어가면)하면 질문
        s = input("토끼가 터널길이를 초과하는 길이를 달렸습니다. 지쳤다고 판단하고 프로그램을 종료하시겠습니까? (Y/N)") #Ops
        if s=='N':
            pass
        elif s=='Y':
            break
    if(R_Dis>=(TL-B_Dis)): #Uturn하는 case 닿는 경우에도 유턴해줘야함  ------ 정확히 닿는 케이스가 생기면(B_Dis와 R_Dis의 공배수) MS를 조절하거나 (TL-B_Dis)-(1/MS)로 조금 더 자세한 계산이 가능
        B_Pos = TL-B_Dis  # 위치 변경의 pivot이 될 B의 위치를 저장해줌(계산용)
        R_Uturn+=1        # Uturn의 값 +1해줌
        TL = B_Pos-A_Dis  # TL을 pivot을 사용하여 초기화 해준 후의 거리로 재설정해줌
        R_Dis-=B_Pos      # R의 현재 거리에서 B_Pos만큼을 빼줌으로써 R의 위치도 새로운 배열에 맞게 배치해줌(R은 계속 한방향으로 움직인다는 뜻)
        tmp=A           # (오류 1의 원인) A와B의 속도까지 바꿔주어야 속성 전체가 바뀜
        A = B         # ""
        B = tmp         # ""
        B_Dis = 0         # B_Dis를 초기값으로 돌려줌
        A_Dis = 0         # A_Dis도 초기값으로 돌려줌 이후로는 새로운 TL에 대한 계산 시작

print("토끼를 잡는데 걸린 시간 = {0:.3f}초\n토끼가 유턴한 횟수 = {1}회\n토끼가 달린 총 거리 = {2:.3f}m\n".format(Catch_Time,R_Uturn,R_TDis))
##소수점 4째자리까지 리턴함----------밀리초 단위가 1/1000이므로 소수점 셋째자리까지만 출력해줌


